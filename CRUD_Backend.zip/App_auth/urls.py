from django.urls import path
from App_auth.views import *
from App_auth.views import verifyEmail
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView


urlpatterns = [
    path('signup/', RegistrationAPIViewWithEmail.as_view(), name='Registration'),
    path("verify-email/", verifyEmail, name="verify-email"),
    path('login/refresh-token/', TokenObtainPairView.as_view()),
    path('login/token/', UserLoginView.as_view()),
    path('changepassword/', UserChangePasswordView.as_view(), name='changepassword'),
    path('profile-view/', UserProfileModelAPIView.as_view()),
    path('profile-update-view/', profile_update_api_view),
    path('user-profile-view/<int:id>/', profile_update_api_view),
]
