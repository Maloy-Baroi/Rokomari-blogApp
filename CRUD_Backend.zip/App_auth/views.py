import json
import uuid

from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.core.mail import send_mail
from django.http import JsonResponse, HttpResponseRedirect, HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from django.urls import reverse
from django.contrib.auth.models import Group

# Models
from App_auth.models import CustomUser, ProfileModel
from App_auth.serializers import *

# Rest API
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework import generics
from rest_framework import status
from rest_framework import renderers
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken


# Create your views here.
class RegistrationAPIViewWithEmail(generics.CreateAPIView):
    queryset = CustomUser.objects.all()
    serializers = RegisterSerializer

    def post(self, request):
        authToken = str(uuid.uuid4())
        email = request.data['email']
        if CustomUser.objects.filter(email=email).exists():
            return Response({"error": "This Email is already used!!!"})
        try:
            full_name = request.data['full_name']
        except:
            full_name=""
        group = "customer"
        user = CustomUser.objects.create(
            email=email,
            full_name=full_name
        )
        print(f"Before If: {authToken}")
        if authToken:
            print(authToken)
            user.set_password(authToken)
        user.save()
        print(group)
        grp = Group.objects.get_or_create(name=group)
        grp[0].user_set.add(user)
        profile_obj = ProfileModel.objects.create(user=user, auth_token=authToken, is_verified=False)
        profile_obj.save()
        send_mail_after_registration(email, authToken, group)
        return Response({"success": f"Sent a mail to {email}. Please Check and verify the account", "auth": f"{authToken}"})

@api_view(['POST'])
def verifyEmail(request):
    if request.method == 'POST':
        password = request.data['password']
        auth_token = request.data['auth_token']
        print(f"Auth Token: {auth_token}, Password: {password}")
        try:
            profile_obj = ProfileModel.objects.filter(auth_token=auth_token)
            print(f"Profile: {profile_obj}")
            if profile_obj.exists():
                if profile_obj[0].is_verified:
                    return Response({"verified": "Your account is already verified."})
                profileObj = ProfileModel.objects.get(auth_token=auth_token)
                profileObj.is_verified = True
                profileObj.save()
                print(profileObj.is_verified)
                thisUser = CustomUser.objects.get(email=profileObj.user)
                thisUser.set_password(password)
                thisUser.save()
                return Response({'success': "We have verified your account."}, status=status.HTTP_200_OK)
            else:
                return Response({'error': "Sorry. Something went wrong!"}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print(e)
            return Response({'error': f"Sorry. It's completely wrong! {e}"}, status=status.HTTP_400_BAD_REQUEST)


def error_page(request):
    return JsonResponse("Error")


def send_mail_after_registration(email, token, group):
    subject = 'CRUD Account Verification!!!'
    message = f'Hi Mr./Ms./Mrs., You have ask to join to CRUD. We are glad to inform you that, you could be verified using this link. Please click on this link to verify your account http://localhost:3000/auth/verify/{token}/'
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, email_from, recipient_list)


def getToken(user):
    refreshToken = RefreshToken.for_user(user)
    return {
        'refresh': str(refreshToken),
        'access': str(refreshToken.access_token)
    }


class UserRendering(renderers.JSONRenderer):
    charset = 'utf-8'
    
    def render(self, data, accepted_media_type=None, renderer_context=None):
        response = ''
        if 'ErrorDetail' in str(data):
            response = json.dumps({'error': data})
        else:
            response = json.dumps(data)

        return response


class UserLoginView(APIView):
    renderer_classes = [UserRendering]
    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        user = authenticate(email=email, password=password)
        if user:
            profile = ProfileModel.objects.filter(user=user)
            if profile.exists():
                if profile[0].is_verified:
                    token = getToken(user)
                    return Response({'access_token': token['access'], "refresh_token": token['refresh'], 'alert': 'Login Success', 'userID': user.id}, status=status.HTTP_200_OK)
                else:
                    return Response({'alert': 'You are not verified yet. Please check your email'}, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response({'alert': 'Login Failed! No User Found.'}, status=status.HTTP_404_NOT_FOUND)


class UserChangePasswordView(APIView):
    renderer_classes = [UserRendering]
    permission_classes = [IsAuthenticated]
    def post(self, request, format=None):
        serializer = UserChangePasswordSerializer(data=request.data, context={'user':request.user})
        serializer.is_valid(raise_exception=True)
        return Response({'alert': 'Password has been changed successfully'}, status=status.HTTP_200_OK)


class UserProfileModelAPIView(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated, ]
    # queryset = ProfileModel.objects.all()
    serializer_class = ProfileModelSerializer

    def get(self, request, *args, **kwargs):
        queryset = ProfileModel.objects.get(user=request.user)
        serializer = self.get_serializer(queryset)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = ProfileModelSerializer(data=request.data, context={'user':request.user})
        if serializer.is_valid():
            serializer.save()
            return Response({'alert': 'Profile set.'}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    # def put()


@api_view(['POST'])
# @permission_classes(['IsAuthenticated'])
def profile_update_api_view(request):
    if request.method == 'POST':
        profile = ProfileModel.objects.get(user=request.user)
        profile.full_name = request.data['full_name']
        profile.phone_number = request.data['phone_number']
        try:
            profile.profile_picture = request.FILES['profile_picture']
        except:
            print("File not Found")
        profile.house = request.data['house']
        profile.area = request.data['area']
        profile.city = request.data['city']
        profile.save()
        
        return Response({"success": "Successfully Updated!!!"})
    return Response({"error": "Update failed"})



class UserProfileAPIView(generics.RetrieveAPIView):
    permission_classes = [IsAuthenticated, ]
    queryset = ProfileModel.objects.all()
    serializer_class = ProfileModelSerializer
    lookup_field = 'id'

