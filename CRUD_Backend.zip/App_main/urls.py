from django.urls import path, re_path
from App_main.views import *


urlpatterns = [
    path('blog-create/', CreateBlogAPIView.as_view(), name='blog-create'),
    path('blog-list/', ListBlogAPIView.as_view(), name='blog-list'),
    path('blog-details/<int:id>/', RetrieveBlogAPIView.as_view(), name='blog-list'),
    re_path(r'^blog-update/(?P<pk>\d+)/$', BlogUpdateAPIView.as_view(), name='blog-update'),
    re_path(r'^blog-delete/(?P<pk>\d+)/$', BlogDeleteAPIView.as_view(), name='blog-delete'),
]
