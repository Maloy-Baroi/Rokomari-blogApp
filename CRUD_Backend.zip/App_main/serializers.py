from rest_framework import serializers
from App_main.models import BlogModel
# from App_auth.serializers import UserModelSerializer

class BlogModelSerializers(serializers.ModelSerializer):
    class Meta:
        model = BlogModel
        fields = ('id', 'author', 'title', 'short_description', 'blog', 'get_author_name')

        read_only_fields = ['author']

    def create(self, validated_data):
        thisBlog = BlogModel.objects.create(author=self.context.get('user'), title=validated_data['title'], short_description=validated_data['short_description'], blog=validated_data['blog'])
        return thisBlog


