from django.shortcuts import render
from django_redis import get_redis_connection

# Rest Framework
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.exceptions import PermissionDenied
from rest_framework.response import Response
from rest_framework import status

# From App
from App_main.models import BlogModel
from App_main.serializers import BlogModelSerializers

# Django Redis
from django.core.cache import cache

# Create your views here.
class CreateBlogAPIView(generics.CreateAPIView):
    permission_classes = [IsAuthenticated]
    queryset = BlogModel.objects.all()
    serializer_class = BlogModelSerializers

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data, context={'user': self.request.user})
        if serializer.is_valid():
            blog = serializer.save()
            return Response({"success": f"Successfully created blog!!!"}, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ListBlogAPIView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    queryset = BlogModel.objects.all()
    serializer_class = BlogModelSerializers

    def get(self, request):
        blogList = cache.get('blogList')
        if blogList:
            print("BlogList From Cache")
            return Response(blogList) 
        queryset = BlogModel.objects.all()
        serializer = self.get_serializer(queryset, many=True)
        cache.set("blogList", serializer.data)
        return Response(serializer.data)


class RetrieveBlogAPIView(generics.RetrieveAPIView):
    queryset = BlogModel.objects.all()
    serializer_class = BlogModelSerializers
    lookup_field = 'id'

    def get(self, request, id):
        blog = cache.get(f"blog_{id}")
        if blog:
            print("Blog From Cache ", id)
            return Response(blog)
        queryset = BlogModel.objects.get(id=id)
        serializer = self.get_serializer(queryset)
        cache.set(f"blog_{id}", serializer.data)
        return Response(serializer.data)


class BlogUpdateAPIView(generics.RetrieveUpdateAPIView):
    permission_classes = [IsAuthenticated]
    queryset = BlogModel.objects.all()
    serializer_class = BlogModelSerializers

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        if instance.author != self.request.user:
            raise PermissionDenied()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def perform_update(self, serializer):
        serializer.save()


class BlogDeleteAPIView(generics.RetrieveDestroyAPIView):
    permission_classes = [IsAuthenticated]
    queryset = BlogModel.objects.all()
    serializer_class = BlogModelSerializers

    def perform_destroy(self, instance):
        if instance.author != self.request.user:
            raise PermissionDenied()
        instance.delete()
