from django.db import models
# from django.contrib.auth.models import User
from App_auth.models import CustomUser
from datetime import datetime


class BlogModel(models.Model):
    author = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='blog_author')
    title = models.CharField(max_length=100)
    short_description = models.CharField(max_length=255)
    blog = models.TextField()

    def __str__(self):
        return f"{self.author}'s blog named {self.title}"

    def get_author_name(self):
        return f"{self.author.full_name}" if self.author.full_name else self.author.email
